import pygame,random
from pygame.locals import *

width = 600
height = 600
FPS = 60
amount = 10
radius = 10

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

def f(x):
    return(x)


class Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.bias = 1
        self.px = int((x) + width/2)
        self.py = int((y*-1) + height/2)

        self.color = BLACK
        line = f(self.x)
        if self.y < line:
            self.label = 1
        else:
            self.label = -1

    def Show(self, surface):
        pygame.draw.circle(surface, self.color,(self.px, self.py),radius-1,0)
        pygame.draw.circle(surface, BLACK,(self.px, self.py),radius,2)

