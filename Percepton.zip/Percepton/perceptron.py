import random

def sign(x):
    if x >= 0:
        output = 1
    else:
        output = -1
    return(output)

class Perceptron():
    def __init__(self, n ):
        self.weights = [n,random.randint(-1,1),random.randint(-1,1)]
        self.rate = 0.01

    def Reset(self):
        for i in range(len(self.weights)):
            self.weights[i] = random.randint(-1,1)

    def Guess(self,inputs):
        sum = 0
        for i in range(len(self.weights)):
            sum += inputs[i] * self.weights[i]
        output = sign(sum)
        return output

    def Train(self, inputs, target):
        guess = self.Guess(inputs)
        error = target - guess
        for i in range(len(self.weights)):
            self.weights[i] += error * inputs[i] * self.rate

