import pygame, sys, random, perceptron, point
from pygame.locals import *

width = 600
height = 600
FPS = 600
amount = int(width/10)

BLACK = (  0,  0,  0)
GREEN = (  0,136,  0)
RED   = (255,  0,  0)
WHITE = (255,255,255)

pygame.init()

DISPLAYSURF = pygame.display.set_mode((width,height))
pygame.display.set_caption('')

fpsClock = pygame.time.Clock()

def f(x):
    return(0)

def main():
    ss = 0
    Steve = perceptron.Perceptron(3)
    points = []
    for i in range(amount):
        x = random.randint((width/2)*-1,width/2)
        y = random.randint((height/2)*-1,height/2)
        i= point.Point(x,y)
        points.append(i)

    p1 = point.Point(-1000,f(-1000))
    p2 = point.Point(1000,f(1000))

    while True:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/' + str(ss) + '.png'
                    pygame.image.save(DISPLAYSURF,pygame.image.save(DISPLAYSURF,name))
                    ss += 1
                elif event.key == 8:
                    Steve.Reset()
                    for i in points:
                        i.color = BLACK
                elif event.key == 32:
                    for i in points:
                        inputs = [i.x,i.y,i.bias]
                        Steve.Train(inputs,i.label)
                else:
                    print(event.key)


        for i in points:
            inputs = [i.x,i.y,i.bias]
            guess = Steve.Guess(inputs)
            if guess == i.label:
                line = f(i.x)
                if i.y < line:
                    i.color = GREEN
                else:
                    i.color = RED
            else:
                i.color = BLACK

        fpsClock.tick(FPS)

    #               Display Screen:
        DISPLAYSURF.fill(WHITE)
        pygame.draw.line(DISPLAYSURF, BLACK, (p1.px,p1.py), (p2.px,p2.py),1)

        for i in points:
            i.Show(DISPLAYSURF)
        pygame.display.update()
main()



